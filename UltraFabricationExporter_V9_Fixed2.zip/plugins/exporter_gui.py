import wx
import os

class ExportDialog(wx.Dialog):
    def __init__(self, default_name):
        super().__init__(None, title="Ultra Fabrication Exporter",
                         size=(520, 280), style=wx.DEFAULT_DIALOG_STYLE)

        panel = wx.Panel(self)
        vbox = wx.BoxSizer(wx.VERTICAL)

        # Save path row
        path_label = wx.StaticText(panel, label="Output PDF:")
        vbox.Add(path_label, flag=wx.LEFT | wx.TOP, border=15)

        self.path_picker = wx.FilePickerCtrl(
            panel,
            message="Save Fabrication PDF",
            wildcard="PDF files (*.pdf)|*.pdf",
            style=wx.FLP_SAVE | wx.FLP_USE_TEXTCTRL | wx.FLP_OVERWRITE_PROMPT
        )
        self.path_picker.SetPath(default_name)
        vbox.Add(self.path_picker, flag=wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, border=15)

        # Checkboxes
        self.edgecuts_checkbox = wx.CheckBox(panel, label="Include Edge.Cuts board outline")
        self.edgecuts_checkbox.SetValue(True)
        vbox.Add(self.edgecuts_checkbox, flag=wx.LEFT | wx.TOP, border=15)

        self.mirror_checkbox = wx.CheckBox(panel, label="Mirror for toner transfer")
        self.mirror_checkbox.SetValue(False)
        vbox.Add(self.mirror_checkbox, flag=wx.LEFT | wx.TOP, border=10)

        self.openpdf_checkbox = wx.CheckBox(panel, label="Auto-open PDF after export")
        self.openpdf_checkbox.SetValue(True)
        vbox.Add(self.openpdf_checkbox, flag=wx.LEFT | wx.TOP, border=10)

        # OK / Cancel buttons
        btn_sizer = wx.StdDialogButtonSizer()
        ok_btn = wx.Button(panel, wx.ID_OK, "Export")
        ok_btn.SetDefault()
        cancel_btn = wx.Button(panel, wx.ID_CANCEL, "Cancel")
        btn_sizer.AddButton(ok_btn)
        btn_sizer.AddButton(cancel_btn)
        btn_sizer.Realize()
        vbox.Add(btn_sizer, flag=wx.ALIGN_RIGHT | wx.ALL, border=15)

        panel.SetSizer(vbox)
        vbox.Fit(panel)
        self.Fit()
        self.Centre()

        ok_btn.Bind(wx.EVT_BUTTON, self.on_ok)

    def on_ok(self, event):
        if not self.path_picker.GetPath():
            wx.MessageBox("Please select an output file path.", "Error", wx.OK | wx.ICON_ERROR)
            return
        self.EndModal(wx.ID_OK)

    def get_values(self):
        return (
            self.path_picker.GetPath(),
            self.edgecuts_checkbox.GetValue(),
            self.mirror_checkbox.GetValue(),
            self.openpdf_checkbox.GetValue()
        )
