import pcbnew
import wx
import os
import webbrowser
from .exporter_gui import ExportDialog

class UltraFabricationExporter(pcbnew.ActionPlugin):
    def defaults(self):
        self.name = "Ultra Fabrication Exporter"
        self.category = "Manufacturing Tools"
        self.description = "Commercial grade fabrication PDF exporter"
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "..", "icon.png")

    def Run(self):
        board = pcbnew.GetBoard()
        board_file = board.GetFileName()
        board_name = os.path.splitext(os.path.basename(board_file))[0] if board_file else "KiCadBoard"
        dlg = ExportDialog(board_name + "_Fabrication_FCu.pdf")
        if dlg.ShowModal() != wx.ID_OK:
            dlg.Destroy()
            return
        save_path, edgecuts, mirror, openpdf = dlg.get_values()
        dlg.Destroy()
        final_pdf = self.export_pdf(board, save_path, edgecuts, mirror)
        if openpdf and os.path.exists(final_pdf):
            webbrowser.open(final_pdf)
        wx.MessageBox("Fabrication PDF exported successfully!", "Success", wx.OK | wx.ICON_INFORMATION)

    def export_pdf(self, board, full_pdf_path, include_edgecuts, mirror_mode):
        folder = os.path.dirname(full_pdf_path)
        if not folder:
            folder = os.path.dirname(board.GetFileName())
        filename = os.path.splitext(os.path.basename(full_pdf_path))[0]

        plot_controller = pcbnew.PLOT_CONTROLLER(board)
        popt = plot_controller.GetPlotOptions()
        popt.SetOutputDirectory(folder)
        popt.SetPlotFrameRef(False)
        popt.SetMirror(mirror_mode)
        popt.SetAutoScale(False)
        popt.SetScale(1)
        popt.SetPlotMode(pcbnew.FILLED)

        # DRILL_MARKS_REAL was renamed to DRILL_MARKS_REAL_SIZE in KiCad 9
        drill_marks = getattr(pcbnew, 'DRILL_MARKS_REAL_SIZE',
                     getattr(pcbnew, 'DRILL_MARKS_REAL', 2))
        popt.SetDrillMarksType(drill_marks)

        if hasattr(popt, "SetBlackAndWhite"):
            popt.SetBlackAndWhite(True)

        plot_controller.SetLayer(pcbnew.F_Cu)
        plot_controller.OpenPlotfile(filename, pcbnew.PLOT_FORMAT_PDF, "Fabrication PDF")
        plot_controller.PlotLayer()
        if include_edgecuts:
            plot_controller.SetLayer(pcbnew.Edge_Cuts)
            plot_controller.PlotLayer()
        plot_controller.ClosePlot()
        return os.path.join(folder, filename + ".pdf")

UltraFabricationExporter().register()
